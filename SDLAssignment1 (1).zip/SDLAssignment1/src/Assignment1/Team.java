package Assignment1;

import java.util.ArrayList;

public class Team {
    public void sellPlayer(Player player,Team destinationClub,double transferSum) {
        if (this._Squad.contains(player)){
            player.setTeam(destinationClub);
            this._Squad.remove(player);
            setTransferBudget(this._TransferBudget + transferSum);
            destinationClub.buyPlayer(player,transferSum);
        }
    }

    public void buyPlayer(Player player,double transferSum) {
        if (!this._Squad.contains(player)){
            player.getTeam().sellPlayer(player,Team.this,transferSum);
            this._Squad.add(player);
            setTransferBudget(this._TransferBudget - transferSum);

        }
    }

    public Team(String Name, ArrayList<Player> Squad, double TransferBudget) {
        this._Name = Name;
        this._Squad = Squad;
        this._TransferBudget = TransferBudget;
    }

    public ArrayList<Player> getSquad() {
        return _Squad;
    }

    public void setSquad(ArrayList<Player> Squad) {
        this._Squad = Squad;
    }

    public double getTransferBudget() {
        return _TransferBudget;
    }

    public void setTransferBudget(double TransferBudget) {
        this._TransferBudget = TransferBudget;
    }

    public String getName() { return _Name; }

    @Override
    public String toString() {
        String retval = "Name = "+ _Name +
                "\nTransferBudget = " + _TransferBudget + "\nSquad = [";
        for (Player p: _Squad) {
            retval += p.getName() + ", ";
        }
        retval += "]";
        return retval;
    }

    private ArrayList<Player> _Squad;
    private double _TransferBudget;
    private String _Name;
}
