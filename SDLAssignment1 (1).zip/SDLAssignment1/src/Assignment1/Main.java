package Assignment1;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        Team Juventus = new Team("Juventus",new ArrayList<>(),112.3);
        Team RealMadrid = new Team("Real Madrid",new ArrayList<>(),217.3);
        Team FCBarcelona = new Team("FC Barcelona",new ArrayList<>(),189.5);

        Player Ronaldo = new Player(94,"Cristiano Ronaldo",33,Juventus);
        Player Messi = new Player(95,"Lionel Messi",33,FCBarcelona);
        Player Bale = new Player(90,"Gareth Bale",28,RealMadrid);
//        ArrayList<String> words = new ArrayList<>();
//        words.add("Hello");
//        words.add("Adios");
//        words.add("Gracias");

//        System.out.println(Ronaldo);

        System.out.println(Juventus);
        System.out.println(RealMadrid);
        System.out.println(FCBarcelona);

        RealMadrid.sellPlayer(Bale,FCBarcelona,80);
        FCBarcelona.sellPlayer(Messi,Juventus,0);
        Juventus.sellPlayer(Ronaldo,RealMadrid,80);


        System.out.println("Teams after following transfers\n" +
                "Messi -> Juventus\n" +
                "Ronaldo -> Real Madrid\n" +
                "Bale -> Barcelona : ");
        System.out.println(Juventus);
        System.out.println(RealMadrid);
        System.out.println(FCBarcelona);
    }
}
