package Assignment1;

public class Player {
    public void trainPlayer() {
        setOVR(this._OVR + Math.random());
    }

    @Override
    public String toString() {
        return "OVR = " + _OVR +
                "\nName = '" + _Name + '\'' +
                "\nAge = " + _Age +
                "\nTeam = " + _Team.getName() +
                "\nValue = " + _Value;
    }



    public Player(double _OVR, String _Name, int _Age, Team _Team) {
        this._OVR = _OVR;
        this._Name = _Name;
        this._Age = _Age;
        this._Team = _Team;
        this._Team.getSquad().add(this);
    }

    public double getOVR() {
        return _OVR;
    }

    public void setOVR(double OVR) {
        this._OVR = OVR;
    }

    public String getName() {
        return _Name;
    }

    public void setName(String Name) {
        this._Name = Name;
    }

    public int getAge() {
        return _Age;
    }

    public void setAge(int Age) {
        this._Age = Age;
    }

    public Team getTeam() {
        return _Team;
    }

    public void setTeam(Team Team) {
        this._Team = Team;
    }

    public double getValue() {
        return _Value;
    }

    public void setValue(double Value) {
        this._Value = Value;
    }

    private double _OVR;
    private String _Name;
    private int _Age;
    private Team _Team;
    private double _Value;
}
